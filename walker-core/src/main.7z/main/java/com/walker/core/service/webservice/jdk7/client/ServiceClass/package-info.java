@javax.xml.bind.annotation.XmlSchema(namespace = "http://serviceImpl.service.util/")
package com.walker.core.service.webservice.jdk7.client.ServiceClass;
