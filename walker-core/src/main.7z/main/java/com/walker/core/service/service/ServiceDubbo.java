package com.walker.core.service.service;


/**
 * dubbo
 *
 */
public interface ServiceDubbo {
	/**
	 * @param name
	 */
	public String sayHello(String name); 
}
