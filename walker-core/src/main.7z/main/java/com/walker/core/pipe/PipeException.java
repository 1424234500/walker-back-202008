package com.walker.core.pipe;

public class PipeException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5002931016898035011L;

	PipeException(String str){
		super(str);
	}
	
}
