package com.walker.common.util;
/**
 * 回调 通用上转 接口 常用于 抽象 启动器 上转
 */
public interface Call{ 
	public void call() ;
}

